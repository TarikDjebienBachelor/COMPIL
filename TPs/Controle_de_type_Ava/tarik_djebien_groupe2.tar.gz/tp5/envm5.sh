#!/bin/sh
# pour avoir JFlex et Cup
export CLASSPATH=.:classes/:../classes/:/usr/share/java/JFlex.jar:/usr/share/java/cup.jar:/home/tarik/Documents/Ressources_Pedagogiques/Informatique/License_Informatique/COMPIL/bcel/bcel-5.2.jar:$CLASSPATH
# pour �tre s�r d'avoir ant + voir les scripts
export PATH=/usr/local/bin:scripts:$PATH
