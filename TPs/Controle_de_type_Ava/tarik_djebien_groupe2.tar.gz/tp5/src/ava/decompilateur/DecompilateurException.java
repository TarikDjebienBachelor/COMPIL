package ava.decompilateur;

import ava.arbreAbstrait.VisiteurException;

public class DecompilateurException extends VisiteurException {

    public DecompilateurException() {
	super();
    }

    public DecompilateurException(String s) {
	super(s);
    }


}