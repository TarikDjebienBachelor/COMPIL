package ava.arbreAbstrait;

/** Instruction d'un programme Ava.
 * @author M. Nebut
 * @version 11/07
 */
public interface Instruction extends Visitable {

}