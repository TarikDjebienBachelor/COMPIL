README : 

// Auteur : Djebien Tarik
// Date   : novembre 2010
// Objet  : Analyseur semantique de AVA (controle de type)

Ci-Joint le TP numero 5 de Compilation, des programmes de Test on était mis dans les dossier OK et KO pour tester la sémantique du langage AVA.


Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
