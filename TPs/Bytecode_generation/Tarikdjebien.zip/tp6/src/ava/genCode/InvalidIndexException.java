package ava.genCode;

public class InvalidIndexException extends Exception {

    

}