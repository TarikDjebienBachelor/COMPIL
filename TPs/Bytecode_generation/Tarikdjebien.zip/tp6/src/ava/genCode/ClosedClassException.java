package ava.genCode;

public class ClosedClassException extends Exception {

    

}