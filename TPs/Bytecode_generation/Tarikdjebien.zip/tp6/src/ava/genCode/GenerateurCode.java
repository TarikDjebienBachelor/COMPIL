package ava.genCode;



import ava.arbreAbstrait.*;
import java.util.Iterator;
import java.io.IOException;

/** Classe servant à générer du bytecode Java à partir d'un arbre
 * abstrait pour Ava. Implanté par un visiteur, utilisation de la classe
 * CG qui sert de point d'accès aux instructions de byteCode.
 * @author M Nebut
 * @version 12/07
 */

public class GenerateurCode { // A COMPLETER

    // point d'accès aux instructions de bytecode
    private GenByteCode generateur;
    // programme à traiter
    private Programme programme;


    /** Crée un générateur de code pour le programme <tt>p</tt>, étant
     * donné un objet <tt>generateur</tt>, point d'accès au bytecode généré.
     * @param generateur l'accès aux instructions de bytecode générées.
     * @param p le programme pour lequel on souhaite générer du code.
     */
    public GenerateurCode(GenByteCode generateur, Programme p) {
	this.generateur = generateur;
	this.programme = p;
    }

    /** Génère le code pour le programme.
     */
    public void generationCode() throws GenCodeException, VisiteurException {
	if (this.programme==null) throw new GenCodeException();
	this.visiteProgramme(this.programme);
    }

    public void visiteProgramme(Programme p) throws GenCodeException,VisiteurException{

	if (p==null) throw new GenCodeException();
	this.visiteListeDecl(p.getListeDecl());
	this.visiteListeInstr(p.getListeInstr());
	this.generateur.closeClass();

    }


    /************************ Déclarations ************************/

    public void visiteListeDecl(ListeDeclaration ldecl) throws VisiteurException{
	Iterator it = ldecl.iterator();
	while (it.hasNext()) {
	    Declaration d = (Declaration) it.next();
	    d.visite(this);
	}
    }

    public void visiteDeclInt(DeclarationEntier decl) throws GenCodeException,VisiteurException{
    try{
	if(decl==null) throw new GenCodeException();
	int idVar= this.generateur.newVarInt(decl.getIdent());
	this.generateur.addICONST_0();
	this.generateur.addISTORE(idVar);
    } catch ( InvalidIndexException e) {
	System.err.println(e.getMessage());
    }
    }

    public void visiteDeclBool(DeclarationBooleen decl) throws GenCodeException,VisiteurException{
    try{
	if(decl==null) throw new GenCodeException();
	int idVar= this.generateur.newVarBool(decl.getIdent());
	this.generateur.addICONST_0();
	this.generateur.addISTORE(idVar);
    }
    catch ( InvalidIndexException e ){
	System.err.println(e.getMessage());
    }
    }

    /************************ Instructions ************************/

    public void visiteListeInstr(ListeInstruction linstr) throws VisiteurException{
	Iterator it = linstr.iterator();
	while (it.hasNext()) {
	    Instruction i = (Instruction) it.next();
	    i.visite(this);
	}
    }

    public void visiteAffect(Affectation a) throws GenCodeException,VisiteurException{
    try{
	if (a == null) throw new GenCodeException();
	a.getExpr().visite(this);
	this.generateur.addISTORE(this.generateur.getIndex(a.getIdent()));
    }
    catch (InvalidIndexException e)
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteLecture(Lecture l) throws VisiteurException{
    try{
	if (l == null) throw new GenCodeException();
	this.generateur.addIREAD();
	this.generateur.addISTORE(this.generateur.getIndex(l.getIdent()));
    }
    catch (InvalidIndexException e)
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteConditionnelleSimple(ConditionnelleSimple l) throws GenCodeException,VisiteurException{
	if (l == null) throw new GenCodeException();
	l.getCondition().visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();

	this.generateur.addIFEQ();
	this.visiteListeInstr(l.getListeInstrAlors());

	int indexSaut = this.generateur.getNextInstructionIndex();
	this.generateur.setTarget(indexIf, indexSaut);
    }

    public void visiteImpressionEntierSansSautDeLigne(ImpressionEntierSansSautDeLigne i) throws GenCodeException,VisiteurException{
	if(i==null)	throw new GenCodeException();
	Expression expr = i.getExpr();
	expr.visite(this);
	this.generateur.addIPRINT();
    }

    public void visiteImpressionEntierAvecSautDeLigne(ImpressionEntierAvecSautDeLigne i) throws GenCodeException,VisiteurException{
	if(i==null) throw new GenCodeException();
	i.getExpr().visite(this);
	this.generateur.addIPRINT();
	this.generateur.addPRINTLN();
    }

    public void visiteImpressionBooleenSansSautDeLigne(ImpressionBooleenSansSautDeLigne i) throws GenCodeException,VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression expr = i.getExpr();
	expr.visite(this);
	this.generateur.addBPRINT();
    }

    public void visiteImpressionBooleenAvecSautDeLigne(ImpressionBooleenAvecSautDeLigne i) throws GenCodeException,VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression expr = i.getExpr();
	expr.visite(this);
	this.generateur.addBPRINT();
	this.generateur.addPRINTLN();
    }

    public void visiteImpressionChaineSansSautDeLigne(ImpressionChaineSansSautDeLigne i) throws GenCodeException,VisiteurException{
    try{
	if(i==null) throw new GenCodeException();
	this.generateur.addLDC(this.generateur.newConstant(i.getChaine()));
	this.generateur.addSPRINT();
    }
    catch ( InvalidIndexException e )
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteImpressionChaineAvecSautDeLigne(ImpressionChaineAvecSautDeLigne i) throws GenCodeException,VisiteurException{
    try{
	if(i==null) throw new GenCodeException();
	this.generateur.addLDC(this.generateur.newConstant(i.getChaine()));
	this.generateur.addSPRINT();
	this.generateur.addPRINTLN();
    }
    catch (InvalidIndexException e)
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteImpressionSautDeLigne(ImpressionSautDeLigne i) throws GenCodeException,VisiteurException{
	if(i==null) throw new GenCodeException();
	this.generateur.addPRINTLN();
    }


    /************************ Expressions ************************/

    public void visiteEntier(Entier e) throws GenCodeException,VisiteurException{
    try{
	if(e==null) throw new GenCodeException();
	this.generateur.addLDC(this.generateur.newConstant(e.getValeur()));
    }
    catch(InvalidIndexException e)
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteIdentExpr(IdentExpr i) throws GenCodeException,VisiteurException{
    try{
	if(i==null) throw new GenCodeException();
    this.generateur.addILOAD(this.generateur.getIndex(i.getNom()));
    }
    catch ( InvalidIndexException e )
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteExprTrue(ExprTrue i) throws GenCodeException,VisiteurException{
    try{
	if(i==null) throw new GenCodeException();
	this.generateur.addLDC(this.generateur.newConstant(1));
    }
    catch ( InvalidIndexException e )
    {
	System.err.println(e.getMessage());
    }
    }

    public void visiteExprFalse(ExprFalse i) throws GenCodeException,VisiteurException{
    try{
	if(i==null) throw new GenCodeException();
	this.generateur.addLDC(this.generateur.newConstant(0));
    }
    catch ( InvalidIndexException e )
    {
	System.err.println(e.getMessage());
	}
    }

    public void visiteAddition(Addition i) throws GenCodeException,VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addIADD();
    }

    public void visiteSoustraction(Soustraction i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addISUB();
    }

    public void visiteMultiplication(Multiplication i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addIMUL();
    }

    public void visiteDivision(Division i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addIDIV();
    }

    public void visiteModulo(Modulo i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addIREM();
    }

    public void visiteMoinsUnaire(MoinsUnaire i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression expr = i.getExpr();
	expr.visite(this);
	this.generateur.addINEG();
    }

    public void visiteNegation(Negation i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression expr = i.getExpr();
	expr.visite(this);
    this.generateur.addINOT();
    }

    public void visiteDisjonction(Disjonction i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
	Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addIOR();
    }

    public void visiteConjonction(Conjonction i) throws VisiteurException{
	if(i==null) throw new GenCodeException();
    Expression gauche = i.getExprGauche();
	gauche.visite(this);

	Expression droite = i.getExprDroite();
	droite.visite(this);
	this.generateur.addINOT();
    }

    public void visiteEgal(Egal e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
	Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPEQ();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

    public void visiteDifferent(Different e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
	Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPNE();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

    public void visiteSuperieurStrict(SuperieurStrict e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
	Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPGT();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

    public void visiteSuperieurOuEgal(SuperieurOuEgal e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
    Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPGE();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

    public void visiteInferieurOuEgal(InferieurOuEgal e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
	Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPLE();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

    public void visiteInferieurStrict(InferieurStrict e) throws VisiteurException{
	if(e==null) throw new GenCodeException();
	Expression gauche = e.getExprGauche();
	gauche.visite(this);

	Expression droite = e.getExprDroite();
	droite.visite(this);
	int indexIf = this.generateur.getNextInstructionIndex();
	this.generateur.addIF_ICMPLT();
	this.generateur.addICONST_0();
	int indexGoto = this.generateur.getNextInstructionIndex();
	this.generateur.addGOTO();
	this.generateur.setTarget(indexIf,this.generateur.getNextInstructionIndex());
	this.generateur.addICONST_1();
	this.generateur.setTarget(indexGoto,this.generateur.getNextInstructionIndex());
    }

}
