package ava.genCode;

import ava.arbreAbstrait.VisiteurException;

public class GenCodeException extends VisiteurException {


    public GenCodeException() {
	super();
    }

    public GenCodeException(String s) {
	super(s);
    }


}
