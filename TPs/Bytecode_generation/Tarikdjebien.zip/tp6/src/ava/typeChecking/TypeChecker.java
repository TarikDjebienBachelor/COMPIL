package ava.typeChecking;

import ava.tableSymboles.*;
import ava.arbreAbstrait.*;

import java.util.Iterator;


/** Contrôle de type pour Ava, qui prend en entrée un arbre abstrait
 * et remplit la table des symboles vide passée en
 * paramètre. L'analyse lève une exception de type
 * <tt>TypeChecking</tt> en cas d'erreur de typage, ne fait rien sinon
 * (à part compléter la table des symboles).
 * @version 04/07
 * @author M. Nebut
 */
public class TypeChecker { // COMPLETER

    // the symbol table to be filled
    private TableSymboles tableSymboles;

    // the abstract tree
    private Programme program;

    // COMPLETER

    /** Builds a type analyzer which fills the symbol table tableSymboles.
     * @param tableSymboles the table to be filled     
     * @param p the abstract tree to be analyzed
     */
    public TypeChecker(TableSymboles tableSymboles, Programme p) {
	this.tableSymboles = tableSymboles;
	this.program = p;
    }

    /** Executes the type analysis.
     * @throws TypeCheckingException if p is badly typed.
     */
    public void typeCheck() throws TypeCheckingException, VisiteurException {
       // COMPLETER
    }

}