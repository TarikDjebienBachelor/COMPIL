package ava.arbreAbstrait;

public interface ImpressionSansSautDeLigne extends Impression {}