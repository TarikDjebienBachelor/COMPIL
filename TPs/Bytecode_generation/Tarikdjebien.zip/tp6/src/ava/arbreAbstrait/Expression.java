package ava.arbreAbstrait;

/** Expression d'un programme Ava.
 * @author M. Nebut
 * @version 11/07
 */
public interface Expression extends Visitable {

}