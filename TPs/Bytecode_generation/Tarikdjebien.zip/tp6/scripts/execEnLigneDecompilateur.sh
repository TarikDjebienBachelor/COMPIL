#!/bin/sh

# exécution de LanceurDecompilateur
# texte à analyser en ligne
#
# M. Nebut 


#*******************************

# la classe contenant votre main
MAIN=ava.executeurs.LanceurDecompilateur

#*******************************

echo "Entrez le texte à analyser :"
java $MAIN
