package ava.arbreAbstrait;

public class VisiteurException extends Exception {

    public VisiteurException() {
	super();
    }

    public VisiteurException(String s) {
	super(s);
    }


}