#!/bin/sh

# exécution de LanceurAnalyseurLexical
# texte à analyser en ligne
#
# M. Nebut 


#*******************************
# la classe contenant votre main
MAIN=ava.executeurs.LanceurAnalyseurLexical

#*******************************

echo "Entrez le texte à analyser :"
java $MAIN
