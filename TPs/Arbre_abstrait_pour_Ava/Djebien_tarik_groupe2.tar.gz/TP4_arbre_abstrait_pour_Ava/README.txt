README : 

// Auteur : Djebien Tarik
// Date   : novembre 2010
// Objet  : TP4 : arbre abstrait pour Ava


Ci-Joint le TP numero 4 de Compilation, tout est fonctionnel :

Remarque:
Le Tp a été realisé en se basant sur le .lex et .cup donné dans l'archive étant donné que en utilisant mes propres .lex et .cup 
les scripts ne fonctionnait pas, surement un problème de compatibilité...

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
