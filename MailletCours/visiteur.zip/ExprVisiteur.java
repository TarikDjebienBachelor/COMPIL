interface ExprVisiteur {
  Object visiterConst(int c);
  Object visiterPlus(Expr expr1, Expr expr2);
  Object visiterMult(Expr expr1, Expr expr2);
}