class Mult extends Expr {
  private Expr expr1, expr2;
  Mult(Expr expr1, Expr expr2) {
    this.expr1 = expr1;
    this.expr2 = expr2;
  }
  Object d�l�guer(ExprVisiteur v) {
    return v.visiterMult(expr1, expr2);
  }
}