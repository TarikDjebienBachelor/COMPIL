class EvalVisiteur implements ExprVisiteur {
  public Object visiterConst(int c) {
    return new Integer(c);
  }
  public Object visiterPlus(Expr expr1, Expr expr2) {
    return 
      new Integer(((Integer)expr1.d�l�guer(this)).intValue() +
                  ((Integer)expr2.d�l�guer(this)).intValue());
  }
  public Object visiterMult(Expr expr1, Expr expr2) {
    return 
      new Integer(((Integer)expr1.d�l�guer(this)).intValue() *
                  ((Integer)expr2.d�l�guer(this)).intValue());
  }
}
