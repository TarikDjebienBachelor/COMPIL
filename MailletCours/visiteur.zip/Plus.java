class Plus extends Expr {
  private Expr expr1, expr2;
  Plus(Expr expr1, Expr expr2) {
    this.expr1 = expr1;
    this.expr2 = expr2;
  }
  Object d�l�guer(ExprVisiteur v) {
    return v.visiterPlus(expr1, expr2);
  }
}