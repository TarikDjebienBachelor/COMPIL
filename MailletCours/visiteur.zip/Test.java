public class Test{

   public static void main(String[] args) {
		Expr expr = new Plus(new Const(2),new Plus (new Const(3), new Const(6)));
		ExprVisiteur eval = new EvalVisiteur();
		ExprVisiteur infixe = new InfixeVisiteur();
		Object valeur = expr.d�l�guer(eval);    // valeur = 11
		Object chaine = expr.d�l�guer(infixe);  // chaine = "2+(3+6)"
		
		System.out.println("Valeur : " + valeur);
		System.out.println("expression : " + chaine);
		// chaine);
	expr = new Mult(new Const(2),new Plus (new Const(3), new Const(6)));
		System.out.println("Valeur : " + expr.d�l�guer(new EvalVisiteur())); // valeur = 18
		System.out.println("expression : " +expr.d�l�guer(new InfixeVisiteur()));// chaine = "2x(3+6)"
		
   }
}