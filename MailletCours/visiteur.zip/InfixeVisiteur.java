class InfixeVisiteur implements ExprVisiteur {
  public Object visiterConst(int c) {
    return Integer.toString(c);
  }
  public Object visiterPlus(Expr expr1, Expr expr2) {
    return 
      "(" +  
      expr1.d�l�guer(this) + 
      "+" + 
      expr2.d�l�guer(this) +
      ")";
  }
  public Object visiterMult(Expr expr1, Expr expr2) {
    return 
      "(" +  
      expr1.d�l�guer(this) + 
      "x" + 
      expr2.d�l�guer(this) +
      ")";
  }
}
