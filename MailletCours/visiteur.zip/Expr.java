abstract class Expr {
  abstract Object d�l�guer(ExprVisiteur v);
}