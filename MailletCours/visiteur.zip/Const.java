class Const extends Expr {
  private int c;
  Const(int c) {
    this.c = c;
  }
  Object d�l�guer(ExprVisiteur v) {
    return v.visiterConst(c);
  }
}
